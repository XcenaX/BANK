﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;
using static System.Console;
namespace Bankomat
{
    class Program
    {

        

        static void SendMessage()
        {
            string resultPage = "";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://api.mobizon.kz/service/Message/SendSmsMessage?recipient=77029742404&text=Lorem+Ipsum&apiKey=kz75419aa9de9506cb026958d6bf22d3e8b5310ba580b157055bb982d4b4e70dd74d74");
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            using (StreamReader sr = new StreamReader(response.GetResponseStream(), Encoding.UTF8, true))
            {
                resultPage = sr.ReadToEnd();
                sr.Close();
            }
        }

        static void WritePath(string path)
        {
            using (StreamWriter writer = new StreamWriter("PATH.txt"))
            {
                writer.WriteLine(path);
            }
        }

        static bool IsLoadPath()
        {
            if(!File.Exists("PATH.txt"))File.Create("PATH.txt");

            using (StreamReader reader = new StreamReader("PATH.txt"))
            {
                var data = reader.ReadToEnd();
                if (data.Length == 0) return false;
                else return true;
            }
        }

        static string LoadPath()
        {
            using (StreamReader reader = new StreamReader("PATH.txt"))
            {
                var data = reader.ReadToEnd();
                data = data.Remove(data.Length-2);
                return data;
            }
        }

        const int ZERO = 0, ONE = 1, TWO = 2, THREE = 3, SEVEN = 7, EIGHT = 8, NINE = 9, TEN = 10,TWELWE=12, FOURTHYFIVE = 45;
        static void Main(string[] args)
         {
            int isPassword, deposit = ZERO;
            int key = ZERO;
            ConsoleKey button;
            bool isPars;
            string loadPath;


            if (!IsLoadPath())
            {
                Write("Введите путь, куда будет сохранятся вся информация: ");
                loadPath = ReadLine();
                WritePath(loadPath);
            }
            else
            {
                loadPath = LoadPath();
            }

            Bank bank = new Bank();

            Client client = new Client();

            bank.LoadInfo(loadPath);
            

            bool check = false;

            while (!check)
            {
            Clear();
            WriteLine("Есть ли у вас аккаунт? y/n");

            char select = ReadKey().KeyChar;
                switch (select)
                {
                    case 'y':
                        Clear();
                       client= bank.LogIn();
                        client.LoadSum(loadPath);
                       if(client.LastName!="" && client.FirstName !="") check = true;
                        Clear();
                        break;
                    case 'n':
                        Clear();
                        var isCreated = bank.CreateAccount();
                        if (isCreated)
                        {
                            bank.clients[bank.clients.Count - 1].SaveUserInfo(loadPath);
                            check = true;
                            client = bank.clients[bank.clients.Count - 1];
                        }
                        Clear();
                        break;
                    default:

                        Clear();
                        break;
                }

            }



            do
            {
                SetCursorPosition(FOURTHYFIVE, SEVEN);
                ForegroundColor = key == ZERO ? ConsoleColor.Green : ConsoleColor.White; WriteLine("->Вывод баланса на экран");
                SetCursorPosition(FOURTHYFIVE, EIGHT);
                ForegroundColor = key == ONE ? ConsoleColor.Green : ConsoleColor.White; WriteLine("->Пополнить счет");
                SetCursorPosition(FOURTHYFIVE, NINE);
                ForegroundColor = key == TWO ? ConsoleColor.Green : ConsoleColor.White; WriteLine("->Снять деньги со счета");
                SetCursorPosition(FOURTHYFIVE, 10);
                ForegroundColor = key == 3 ? ConsoleColor.Green : ConsoleColor.White; WriteLine("->Посмотреть все действия с картой");
                SetCursorPosition(FOURTHYFIVE, 11);
                ForegroundColor = key == 5 ? ConsoleColor.Green : ConsoleColor.White; WriteLine("->Перевести деньги на другой аккаунт");
                SetCursorPosition(FOURTHYFIVE, 12);
                ForegroundColor = key == 6 ? ConsoleColor.Green : ConsoleColor.White; WriteLine("->Выход");

                button = ReadKey().Key;
                Clear();

                if (button == ConsoleKey.DownArrow && key != 5)
                {
                    key++;
                }

                else if (button == ConsoleKey.UpArrow && key != ZERO)
                {
                    key--;
                }

                else if (button == ConsoleKey.Enter)
                {
                    if (key == ZERO)
                    {
                        WriteLine(bank.Print(client));

                        ReadKey();
                        Clear();
                    }

                    else if (key == ONE)
                    {
                        SetCursorPosition(2, TWELWE);
                        WriteLine("Введите сумму которую хотите внести на счет");
                       
                        isPars = int.TryParse(ReadLine(),out deposit);
                        if (isPars == true)
                        {
                            if (deposit > 0)
                            {
                                SetCursorPosition(FOURTHYFIVE, TWELWE + TWO);
                                bank.Add(loadPath, deposit, client);
                                bank.ReplenishAmount(client.account, deposit);

                            }
                            else
                            {
                                Clear();
                                WriteLine("Вы ввели отрицательное число!");
                                ReadKey();
                            }
                        }
                        else
                        {
                            Clear();
                            WriteLine("\nНе коректный ввод данных, пожалуйста в следущий раз введите данные коректно.");
                            WriteLine("\nДля продолжение нажимите на любую клавишу. ");
                            ReadKey();
                        }
                        Clear();
                    }

                    else if (key == TWO)
                    {
                        SetCursorPosition(2, TWELWE);
                        WriteLine("Введите сумму которую хотите снять со счета");
                        
                        isPars = int.TryParse(ReadLine(), out deposit);
                        if (isPars == true)
                        {
                            SetCursorPosition(FOURTHYFIVE, TWELWE+TWO);
                            bank.Withdraw(loadPath,deposit,client);                            
                            bank.PullAmount(client.account, deposit);

                        }
                        else
                        {
                            WriteLine("\nНе коректный ввод данных, пожалуйста в следущий раз введите данные коректно.");
                            WriteLine("\nДля продолжение нажимите на любую клавишу. ");
                            ReadKey();
                        }

                        Clear();
                    }

                    else if (key == 3)
                    {
                        Clear();
                        WriteLine(bank.GetHistoryOfAccount(loadPath, client));
                        WriteLine("\n\nНажмите любую кнопку . . .");
                        ReadKey();
                        Clear();
                    }

                    else if(key == 4)
                    {
                        Clear();
                        WriteLine("Введите ID, email, ИИН или телефон аккаунта на который хотите перевести деньги");
                        string data = ReadLine();

                        if (bank.CheckSameAccount(data))
                        {
                            var toClient = bank.GetClient(data);
                            while (true)
                            {                               

                                Write("Введите количество денег для перевода: ");
                                string toParse = ReadLine();
                                int money;
                                if (int.TryParse(toParse, out money) && money > 0)
                                {
                                    bank.ToAnotherAccount(loadPath, money, client, toClient);
                                    break;
                                }
                                else
                                {
                                    Clear();
                                    WriteLine("Некорректно введены данные!");
                                }
                            }
                        }
                        else
                        {
                            Clear();
                            WriteLine("\nТакого аккаунта не найдено!\nНажмите любую кнопку . . .");
                            ReadKey();
                            Clear();
                            

                        }

                    }

                    else if (key == 5)
                    {

                        Environment.Exit(ZERO);
                    }

                }

            } while (true);
        }
    }
}
