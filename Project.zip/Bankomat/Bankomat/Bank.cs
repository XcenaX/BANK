﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;
using static System.Console;

namespace Bankomat
{
    public class Bank
    {

        public List<Client> clients { get; set; }

        public Bank()
        {
            clients = new List<Client>();
        }

        public void AddAccount(Client client)
        {
            clients.Add(client);
        }

        public bool CheckSameAccount(string data)
        {
            for(int i = 0; i < clients.Count; i++)
            {
                if (data == clients[i].account.Id) return true;
                else if (data == clients[i].account.Phone) return true;
                else if (data == clients[i].account.IIN) return true;
                else if (data == clients[i].account.Mail) return true;
            }
            return false;
        }

        public Client LogIn()
        {
            string data;
            while (true)
            {
                WriteLine("Чтобы отменить вход введите exit\nЧтобы войти введите ID, телефон или ИИН: ");
                data = ReadLine();

                if (data == "exit") return new Client();

                if (!CheckSameAccount(data))
                {
                    Clear();
                    WriteLine("Такого аккаунта не существует!");
                }
                else break;
            }

            Client client = new Client();

            for (int i = 0; i < clients.Count; i++)
            {
                if (data == clients[i].account.IIN || data == clients[i].account.Phone)
                {
                    client = clients[i];
                    break;
                }
            }

            return client;
        }

        public void LoadInfo(string path)
        {
            DirectoryInfo directoryInfo = new DirectoryInfo(path);
            var data = directoryInfo.GetDirectories();

            for(int i = 0; i < data.Length; i++)
            {
                var files = data[i].GetFiles();
                for(int j = 0; j < files.Length; j++)
                {
                    var nameOfFile = files[j].Name;
                    using (StreamReader reader = new StreamReader(data[i].FullName + "/" + nameOfFile))
                    {
                       string fileContent = reader.ReadToEnd();
                        var buf = fileContent.Split('\n','\r');
                        string[] buf2 = new string[6];
                        int H = 0;
                        for(int h =0; h < buf.Length; h++)
                        {
                            if (buf[h] != "")
                            {
                                buf2[H] = buf[h];
                                H++;
                            }
                        }
                        Client client = new Client();
                        client.FirstName = buf2[0];
                        client.LastName = buf2[1];
                        client.account.IIN = buf2[3];
                        client.account.Mail = buf2[5];
                        client.account.Phone = buf2[4];
                        client.account.Id = buf2[2];
                        AddAccount(client);
                    }
                }
            }
          
            
        }

        public static string PasswordGenerate(int length)
        {
            Random _random = new Random(Environment.TickCount);

            string chars = "0123456789abcdefghijklmnopqrstuvwxyz";
            StringBuilder builder = new StringBuilder(length);

            for (int i = 0; i < length; ++i)
                builder.Append(chars[_random.Next(chars.Length)]);

            return builder.ToString();
        }


        public bool CreateAccount()
        {
            Client client = new Client();
            int password2 = new Random().Next(1000, 9999);
            int id = new Random().Next(100000000, 999999999);
            string idStr = id.ToString();
            string Mail = "";

            string password = password2.ToString();

            int isPassword;
            string sayInfo = "Введите exit чтобы отменить регистрацию";

            WriteLine(sayInfo);

            WriteLine("Введите фамилию:");
            string lastName = ReadLine();
            if (lastName == "exit") return false;

            WriteLine("\nВведите имя:");
            string firstName = ReadLine();

            if (firstName == "exit") return false;

            string IIN;
                Clear();
            while (true)
            {
                WriteLine(sayInfo);
                WriteLine("\nВведите ваш ИИН:");
                IIN = ReadLine();
                if (IIN == "exit") return false;

                if (CheckSameAccount(IIN))
                {
                    Clear();
                    WriteLine("Пользователь с таким ИИН уже существует!");
                    WriteLine(sayInfo);
                }
                else break;
            }
            Clear();
            string phone;
                int phoneNumber;
            while (true)
            {
                WriteLine(sayInfo);
                WriteLine("\nВведите ваш телефон:");
                phone = ReadLine();
                if (phone == "exit") return false;

                if (CheckSameAccount(phone))
                {
                    Clear();
                    WriteLine("Пользователь с таким телефоном уже существует!");
                    WriteLine(sayInfo);
                }
                else if (!int.TryParse(phone, out phoneNumber))
                {
                    Clear();
                    WriteLine("Вы ввели не телефон!");
                }
                else
                {
                    Clear();

                    while (true)
                    {

                        Write("Введите код, который пришел вам на телефон:");
                        break;
                    }
                    break;
                }
            }


            while (true)
            {
                WriteLine(sayInfo);
                WriteLine("\nВведите ваш email:");
                Mail = ReadLine();
                if (phone == "exit") return false;

                if (CheckSameAccount(Mail))
                {
                    Clear();
                    WriteLine("Пользователь с таким email уже существует!");
                    WriteLine(sayInfo);
                }
                else
                {
                    Clear();

                    while (true)
                    {
                        string Code = PasswordGenerate(5);
                        string message = "Здравствуйте! Вот ваш код: " + Code + "\nПросто введите его! :)";
                        SendMail(message, "vlad-057@mail.ru", Mail);
                        Write("Введите код, который пришел вам на email:");
                        string code = ReadLine();

                        if (Code == code)
                        {
                            WriteLine("email успешно подтвержден!\nНажмите любую кнопку . . .");
                            ReadKey();
                            Clear();
                            break;
                        }
                    }
                    break;
                }
            }


            if (lastName.Length > 0 && firstName.Length > 0)
            {
                WriteLine("Номер вашего лицевого счёта: " + id);
                WriteLine("\nВаш ПИН-КОД: " + password);
                WriteLine("\nДля продолжение нажимите на любую клавишу. ");
                ReadKey();
            }

            else
            {
                WriteLine("\nНе коректный ввод данных, пожалуйста в следущий раз введите данные коректно.");
                ReadKey();
                Environment.Exit(0);
            }


            int count = 3;
            bool stop = true;


            while (stop == true)
            {

                WriteLine("\nВведите ваш ПИН-КОД, у вас есть " + count + " попытки");
                bool isPars = int.TryParse(ReadLine(), out isPassword);

                if (isPars == true)
                {
                    if (isPassword.ToString() == password)
                    {
                        WriteLine("\nВсё коректно.");
                        WriteLine("\nДля продолжение нажимите на любую клавишу. ");
                        ReadKey();

                        stop = false;
                    }
                    if (count == 0)
                    {
                        WriteLine("\nВы исчерпали количество попыток. ");
                        WriteLine("\nДля продолжение нажимите на любую клавишу. ");
                        ReadKey();
                        Environment.Exit(0);
                    }
                    count--;
                }

                else
                {
                    WriteLine("\nНе коректный ввод данных, пожалуйста в следущий раз введите данные коректно.");
                    WriteLine("\nДля продолжение нажимите на любую клавишу. ");
                    ReadKey();
                    Environment.Exit(0);
                }

                Clear();
                client.FirstName = firstName;
                client.LastName = lastName;
                client.account.Id = idStr;
                client.account.IIN = IIN;
                client.account.Password = password;
                client.account.Phone = phone;
                client.account.Mail = Mail;
                AddAccount(client);
            }
            return true;
        }

        public string Print(Client client)
        {
            return
                "Клиент: " +client.FirstName + " " + client.LastName +
                "\nНомер счета: " + client.account.Id +
                "\nСумма на счете: " + client.account.Amount + " тенге";
        }
        public void ReplenishAmount(Account account, int deposit)
        {
            account.Amount+= deposit;
            Console.WriteLine("Счет пополнен");
            WriteLine("\nНажмите любую кнопку . . .");
            Console.ReadKey();
        }
        public void PullAmount(Account account, int deposit)
        {
            if (account.Amount >= deposit)
            {
                account.Amount -= deposit;
                Console.WriteLine("Сумма со счета снята");
                WriteLine("\nНажмите любую кнопку . . .");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("На счете недостаточно средств");
                WriteLine("\nНажмите любую кнопку . . .");
                Console.ReadKey();
            }
        }


        public void Add(string path, int depositAmount, Client client)
        {
            string buffer = "", info = "transactions.txt", buf = "";
            string folder = "money";
            int value;
            string fileName = "account.txt";
            string nesessaryFolder = client.account.Id;
            try
            {
                if (!Directory.Exists(path + "/" + nesessaryFolder + "/" + folder  ))
                {
                    Directory.CreateDirectory(path + "/" + nesessaryFolder + "/" + folder  );
                }
                if (!File.Exists(  path + "/" + nesessaryFolder + "/" + folder + "/" + fileName))
                {
                    using (File.Create(path + "/" + nesessaryFolder + "/" + folder + "/" + fileName)) { }
                    
                }
                if (!File.Exists(  path + "/" + nesessaryFolder + "/" + folder + "/" + info))
                {
                    using (File.Create(path + "/" + nesessaryFolder + "/" + folder + "/" + info)) { }
                }

                
                using (StreamReader streamReader = new StreamReader( path + "/" + nesessaryFolder + "/" + folder + "/" + fileName))
                {

                    buffer = streamReader.ReadToEnd();
                    int.TryParse(string.Join("", buffer.Where(c => char.IsDigit(c))), out value);
                    if (depositAmount <= 0)
                    {
                        WriteLine("Не коректный ввод данных");
                        Environment.Exit(0);
                        ReadKey();
                    }
                    value += depositAmount;
                }
                using (StreamReader streamReader = new StreamReader( path + "/" + nesessaryFolder + "/" + folder + "/" + info))
                {
                    buf = streamReader.ReadToEnd();
                }
                using (StreamWriter streamWriter = new StreamWriter( path + "/" + nesessaryFolder + "/" + folder + "/" + info))
                {
                    streamWriter.WriteLine(buf + "\nВы пополнили баланс на " + depositAmount  + ", Ваш счет: " + value + ", Время: " + DateTime.Now);
                }
                using (StreamWriter streamWriterInfo = new StreamWriter(path + "/" + nesessaryFolder + "/" + folder + "/" + fileName))
                {
                    streamWriterInfo.WriteLine(value);
                }
            }
            catch (IOException exception)
            {
                WriteLine(exception.Message);
            }
           
        }
        public void Withdraw(string path, int depositAmount, Client client)
        {
            string buffer = "", info = "transactions.txt", buf = "";
            int value;
            string folder = "money";

            string fileName = "account.txt";
            string nesessaryFolder = client.account.Id;

           

            if (!Directory.Exists( path + "/" + nesessaryFolder + "/" + folder ))
            {
                Directory.CreateDirectory( path + "/" + nesessaryFolder + "/" + folder );
            }
            try
            {
                if (!File.Exists( path + "/" + nesessaryFolder + "/" + folder + "/" + fileName))
                {
                    using (File.Create(path + "/" + nesessaryFolder + "/" + folder + "/" + fileName)) { }
                }
                if (!File.Exists( path + "/" + nesessaryFolder + "/" + folder + "/" + info))
                {
                    using (File.Create(path + "/" + nesessaryFolder + "/" + folder + "/" + info)) { }
                }


                    int value2;
                using (StreamReader streamReader = new StreamReader( path + "/" + nesessaryFolder + "/" + folder + "/" + fileName))
                {
                    buffer = streamReader.ReadToEnd();
                    int.TryParse(buffer, out value2);
                    if (depositAmount > value2)
                    {
                        WriteLine("Не коректный ввод данных");
                        Environment.Exit(0);
                        ReadKey();
                    }
                    value2 -= depositAmount;
                }
                using (StreamReader streamReader = new StreamReader( path + "/" + nesessaryFolder + "/" + folder + "/" + info))
                {
                    buf = streamReader.ReadToEnd();
                }
                using (StreamWriter streamWriter = new StreamWriter( path + "/" + nesessaryFolder + "/" + folder + "/" + info))
                {
                    streamWriter.WriteLine(buf + "\nВы сняли с баланса: " + depositAmount  + ", Остаток: " + value2 + ", Время: " + DateTime.Now);
                }
                using (StreamWriter streamWriterInfo = new StreamWriter( path + "/" + nesessaryFolder + "/" + folder + "/" + fileName))
                {
                    streamWriterInfo.WriteLine(value2);
                }
            }
            catch (IOException exception)
            {
                WriteLine(exception.Message);
            }

        }

        public string GetHistoryOfAccount(string loadpath, Client client)
        {
            string currentFolder = client.account.Id;
            using (StreamReader streamReader = new StreamReader(loadpath + "/" + currentFolder + "/money/transactions.txt"))
            {
                var buf = streamReader.ReadToEnd();
                return buf;
            }
        }

        void SendMail(string message, string from, string to)
        {
            HttpWebRequest
          // отправитель - устанавливаем адрес и отображаемое в письме имя
          MailAddress;
            var From = new MailAddress(from, "Bank System \"Aurora\"");
            // кому отправляем
            MailAddress To = new MailAddress(to);
            // создаем объект сообщения
            MailMessage m = new MailMessage(From, To);
            // тема письма
            m.Subject = "Проверка";
            // текст письма
            m.Body = $"<h2>{message}</h2>";
            // письмо представляет код html
            m.IsBodyHtml = true;
            // адрес smtp-сервера и порт, с которого будем отправлять письмо
            SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
            // логин и пароль
            smtp.Credentials = new NetworkCredential("auro rabanksystem@gmail.com", "Samsung12345");
            smtp.EnableSsl = true;
            smtp.Send(m);
        }

       
        public Client GetClient(string data)
        {
            for (int i = 0; i < clients.Count; i++)
            {
                if (data == clients[i].account.Id) return clients[i];
                else if (data == clients[i].account.Phone) return clients[i];
                else if (data == clients[i].account.IIN) return clients[i];
                else if (data == clients[i].account.Mail) return clients[i];
            }
            return new Client();
        }

        public void ToAnotherAccount(string path, int money, Client fromClient, Client toClient)
        {
            if (fromClient.account.Amount < money)
            {
                Clear();
                WriteLine("У вас недостаточно денег для перевода!");
                return;
            }

            Withdraw(path,money,fromClient);
            PullAmount(fromClient.account, money);

            Add(path, money, toClient);
            ReplenishAmount(toClient.account, money);
        }

    }
}
