﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.IO;

namespace Bankomat
{
    public class Client
    {
        public string FirstName { get; set; } 
        public string LastName { get; set; }  
        public Account account { get; set; }

        public Client(string firstName, string lastName)
        {
            FirstName = firstName;
            LastName = lastName;
            account = new Account();
        }

        public Client()
        {
            FirstName = "";
            LastName = "";
            account = new Account();
        }


        public void LoadSum(string loadpath)
        {
            string currentFolder = account.Id;
            using (StreamReader streamReader = new StreamReader(loadpath + "/" + currentFolder + "/money/account.txt"))
            {
                var buf = streamReader.ReadToEnd();
                account.Amount = Convert.ToInt32(buf);
            }
        }

        public void SaveUserInfo(string path)
        {
            var pathOfDirectory = path + "/" + account.Id.ToString();
            Directory.CreateDirectory(pathOfDirectory);

            var pathOfFile = pathOfDirectory + "/info.txt";
            StreamWriter writer = new StreamWriter(pathOfFile);
            // FileStream file = new FileStream(pathOfFile, FileMode.OpenOrCreate);

            var data = (FirstName);
            // var buf = Convert.ToByte(data);
            writer.WriteLine(data);

            // buf = Convert.ToByte("Отчество: " + LastName);
            writer.WriteLine(LastName);

            // buf = Convert.ToByte("Id: " + account.Id);
            writer.WriteLine( account.Id);

            // buf = Convert.ToByte("Пароль: " + account.Password);
            writer.WriteLine(account.Password);

            writer.WriteLine(account.Phone);

            writer.WriteLine(account.Mail);

            writer.Close();
        }

        public string LoadUserInfo(string path)
        {
            var pathOfFile = path + "/" + account.IIN;
            StreamReader reader = new StreamReader(pathOfFile);

            var data = reader.ReadToEnd();

            return data;
        }

       
            

    }
}
