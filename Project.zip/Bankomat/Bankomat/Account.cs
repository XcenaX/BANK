﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bankomat
{
    public class Account
    {
        public string Id { get; set; }
        public string Password { get; set; } 
        public double Amount { get; set; } 
        public string Phone { get; set; }
        public string IIN{ get; set; }
        public DateTime DateOfCreate { get; private set; }
        public string Mail { get; set; }

        public Account()
        {
            Id = "";
            Password = "";
            Amount = 0;
            Phone = "";
            IIN = "";
            DateOfCreate = DateTime.Now;
            Mail = "";
        }
    }
}
